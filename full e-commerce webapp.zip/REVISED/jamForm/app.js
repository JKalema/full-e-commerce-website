const file = document.getElementById('file-upload');
const button = document.getElementById('customBtn');
const text = document.getElementById('custom-text');
const preview = document.querySelector('.post');
// form blur event listener
document.getElementById("name").addEventListener('blur',validateName);
document.getElementById("location").addEventListener('blur',validateLocation);
document.getElementById('zip').addEventListener('blur',zipCode);
document.getElementById('email').addEventListener('blur',email);
 document.getElementById('licence').addEventListener('blur',licence);
document.getElementById('password').addEventListener('blur',password);
 document.getElementById('comform').addEventListener('blur',comform);

//view password 
document.getElementById('eye').addEventListener('click',togglePass);


// button to get file
button.addEventListener('click',function(){
    file.click();
    preview.style.display = "block";


})
// listener to value change
file.addEventListener('change',function(){
    if(file.value){
        text.textContent=file.value.match(/[\/\\]([\w\d\s\.\-\(\)]+)$/)[1];
    }else{
        text.textContent = "No file chosen, yet";
    }
})
 
// image display
function previewImage(event){
    const reader = new FileReader();
    const imageField = document.getElementById('imagefield');
    reader.onload = function(){
        if(reader.readyState == 2){
            imageField.src = reader.result;

        }
    }
    reader.readAsDataURL(event.target.files[0]);


}
function validateName(){
    const name = document.getElementById('name');
    const re = /^[A-Za-z]{2,}\s[A-Za-z]{2,}(\s[A-Za-z]{2,8})?$/
    if(!re.test(name.value)){
        name.classList.add('is-invalid');
    }else{
        name.classList.remove('is-invalid')
        name.classList.add('is-valid');
        setTimeout(()=>{
            name.classList.remove('is-valid');
        },2000);
        
    }
}
function validateLocation(){
    const location = document.getElementById('location');
    const re = /^[A-Za-z]{2,}\s[A-Za-z]{2,}\s[A-Za-z]{2,}$/;
    if(!re.test(location.value)){
        location.classList.add('is-invalid');
    }else{
        location.classList.remove('is-invalid')
        location.classList.add('is-valid');
        setTimeout(()=>{
            location.classList.remove('is-valid');
        },2000);
        
    }
    
}
function zipCode(){
    const zip = document.getElementById('zip');
    const re = /^\(?\D\d{3}\)?[-. ]?\d{3}[-. ]?\d{3}[-. ]?\d{3}$/;
    if(!re.test(zip.value)){
        zip.classList.add('is-invalid');
    }else{
        zip.classList.remove('is-invalid')
        zip.classList.add('is-valid');
        setTimeout(()=>{
            zip.classList.remove('is-valid');
        },2000);
        
    }
}
function email(){
    const email= document.getElementById('email');
    const re = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    if(!re.test(email.value)){
        email.classList.add('is-invalid');
    }else{
        email.classList.remove('is-invalid');
        email.classList.add('is-valid');
        setTimeout(()=>{
            email.classList.remove('is-valid');
        },2000);
        
    }

}
function licence(){
    const licence= document.getElementById('licence');
    const re= /^0+0+[0-9]{8}$/
    if(!re.test(licence.value)){
        licence.classList.add('is-invalid');
    }else{
        licence.classList.remove('is-invalid');
        licence.classList.add('is-valid');
        setTimeout(()=>{
            licence.classList.remove('is-valid');
        },2000);
        
    }
}
// password check
function password(){
    const password = document.getElementById('password')
    const str = document.getElementById('password').value;
    const feedback = document.querySelector('.feedback');
    if(str.length < 8){
        password.classList.add('is-invalid');
        feedback.textContent="password to short";
        

    }else if(str.search(/[0-9]/)==-1){
        password.classList.add('is-invalid');
        feedback.textContent="Atleast 1 numeric value must be entered";

    }else if(str.search(/[a-z]/)==-1){
        password.classList.add('is-invalid');
        feedback.textContent="Atleast 1 small letter must be entered";

    }else if(str.search(/[A-Z]/)==-1){
        password.classList.add('is-invalid');
        feedback.textContent="Atleast 1 uppercase letter must be entered";

    }else if(str.search(/[!\@\#\$\%\^\&\(\)\_\+\.\,\;\:]/)==-1){
        password.classList.add('is-invalid');
        feedback.textContent="Atleast 1 special character must be entered & not allow ~,`,*,<,>,?,";

    }else{
        password.classList.remove('is-invalid')
        password.classList.add('is-valid');
        setTimeout(()=>{
            password.classList.remove('is-valid');
        },2000);
        
    }
}
// view password func
function togglePass(){
    const passwd = document.getElementById('password');
    const eye = document.getElementById('eye');
    eye.classList.toggle("active");
    if(passwd.type==="password"){
        passwd.type="text"
    }else{
        passwd.type="password"
    }

}
function comform(){
    const comformId = document.getElementById('comform');
    const comform = document.getElementById('comform').value;
    const passwd = document.getElementById('password').value;
    if(passwd==comform){
        comformId.classList.add('is-valid');
        setTimeout(()=>{
            comformId.classList.remove('is-valid');
        },2000);

    }else{
        comformId.classList.add('is-invalid');
    }


}