// Requires jQuery

$(document).on('click', '.js-menu_toggle.closed', function(e) {
    e.preventDefault();
    $('.list_load, .list_item').stop();
    $(this).removeClass('closed').addClass('opened');

    $('.side_menu').css({ 'left': '0px' });

    var count = $('.list_item').length;
    $('.list_load').slideDown((count * .6) * 100);
    $('.list_item').each(function(i) {
        var thisLI = $(this);
        timeOut = 100 * i;
        setTimeout(function() {
            thisLI.css({
                'opacity': '1',
                'margin-left': '0'
            });
        }, 100 * i);
    });
});

$(document).on('click', '.js-menu_toggle.opened', function(e) {
    e.preventDefault();
    $('.list_load, .list_item').stop();
    $(this).removeClass('opened').addClass('closed');

    $('.side_menu').css({ 'left': '-250px' });

    var count = $('.list_item').length;
    $('.list_item').css({
        'opacity': '0',
        'margin-left': '-20px'
    });
    $('.list_load').slideUp(300);
});

/*
SLIDING TOP MENU*/
var slider = $('#slider');
var track = slider.find('.track');
var modnum = slider.find('.thumb').length;
var modwidth = slider.find('.thumb').eq(0).outerWidth();
var trackwidth = slider.find('.slider-container').outerWidth();
var overflow = modnum * modwidth - trackwidth;

track.width(modnum * modwidth);

if (modnum > 4) {
    $('.btnPrev').show();
    $('.btnNext').show();
}

$('.btnPrev').click(function() {
    var left = parseInt(track.css("marginLeft"), 10);
    track.queue("steps", function(next) {

        if (left >= 0) {
            track.animate({
                marginLeft: '+=50px'
            }, 130);
        } else {
            track.animate({
                marginLeft: '+=160px'
            }, 260);
        }
        next();

    }).queue("steps", function(next) {

        if (left >= 0) {
            track.animate({
                marginLeft: 0
            }, 130);
        }
        next();

    }).dequeue("steps");
});

$('.btnNext').click(function() {
    var left = parseInt(track.css("marginLeft"), 10);
    track.queue("steps", function(next) {

        if (Math.abs(left) >= overflow - modwidth) {
            track.animate({
                marginLeft: '-=50px'
            }, 130);
        } else {
            track.animate({
                marginLeft: '-=160px'
            }, 260);
        }
        next();

    }).queue("steps", function(next) {

        if (Math.abs(left) >= overflow - modwidth) {
            track.animate({
                marginLeft: -overflow
            }, 130);
        }
        next();

    }).dequeue("steps");
});

//END OF SLIDING TOP MENU



//START OF SLIDING FIRST DIV FOR JJAM SHOW CASING


$(document).ready(function() {

    var $slider = $(".slider"),
        $slideBGs = $(".slide__bg"),
        diff = 0,
        curSlide = 0,
        numOfSlides = $(".slide").length - 1,
        animating = false,
        animTime = 500,
        autoSlideTimeout,
        autoSlideDelay = 6000,
        $pagination = $(".slider-pagi");

    function createBullets() {
        for (var i = 0; i < numOfSlides + 1; i++) {
            var $li = $("<li class='slider-pagi__elem'></li>");
            $li.addClass("slider-pagi__elem-" + i).data("page", i);
            if (!i) $li.addClass("active");
            $pagination.append($li);
        }
    };

    createBullets();

    function manageControls() {
        $(".slider-control").removeClass("inactive");
        if (!curSlide) $(".slider-control.left").addClass("inactive");
        if (curSlide === numOfSlides) $(".slider-control.right").addClass("inactive");
    };

    function autoSlide() {
        autoSlideTimeout = setTimeout(function() {
            curSlide++;
            if (curSlide > numOfSlides) curSlide = 0;
            changeSlides();
        }, autoSlideDelay);
    };

    autoSlide();

    function changeSlides(instant) {
        if (!instant) {
            animating = true;
            manageControls();
            $slider.addClass("animating");
            $slider.css("top");
            $(".slide").removeClass("active");
            $(".slide-" + curSlide).addClass("active");
            setTimeout(function() {
                $slider.removeClass("animating");
                animating = false;
            }, animTime);
        }
        window.clearTimeout(autoSlideTimeout);
        $(".slider-pagi__elem").removeClass("active");
        $(".slider-pagi__elem-" + curSlide).addClass("active");
        $slider.css("transform", "translate3d(" + -curSlide * 100 + "%,0,0)");
        $slideBGs.css("transform", "translate3d(" + curSlide * 50 + "%,0,0)");
        diff = 0;
        autoSlide();
    }

    function navigateLeft() {
        if (animating) return;
        if (curSlide > 0) curSlide--;
        changeSlides();
    }

    function navigateRight() {
        if (animating) return;
        if (curSlide < numOfSlides) curSlide++;
        changeSlides();
    }

    $(document).on("mousedown touchstart", ".slider", function(e) {
        if (animating) return;
        window.clearTimeout(autoSlideTimeout);
        var startX = e.pageX || e.originalEvent.touches[0].pageX,
            winW = $(window).width();
        diff = 0;

        $(document).on("mousemove touchmove", function(e) {
            var x = e.pageX || e.originalEvent.touches[0].pageX;
            diff = (startX - x) / winW * 70;
            if ((!curSlide && diff < 0) || (curSlide === numOfSlides && diff > 0)) diff /= 2;
            $slider.css("transform", "translate3d(" + (-curSlide * 100 - diff) + "%,0,0)");
            $slideBGs.css("transform", "translate3d(" + (curSlide * 50 + diff / 2) + "%,0,0)");
        });
    });

    $(document).on("mouseup touchend", function(e) {
        $(document).off("mousemove touchmove");
        if (animating) return;
        if (!diff) {
            changeSlides(true);
            return;
        }
        if (diff > -8 && diff < 8) {
            changeSlides();
            return;
        }
        if (diff <= -8) {
            navigateLeft();
        }
        if (diff >= 8) {
            navigateRight();
        }
    });

    $(document).on("click", ".slider-control", function() {
        if ($(this).hasClass("left")) {
            navigateLeft();
        } else {
            navigateRight();
        }
    });

    $(document).on("click", ".slider-pagi__elem", function() {
        curSlide = $(this).data("page");
        changeSlides();
    });

});



//END OF SLIDING FIRST DIV FOR JJAM SHOW CASING


//START OF BUSINESS DIV GRIDS

$(document).ready(function() {
    var zindex = 10;

    $("div.card").click(function(e) {
        e.preventDefault();

        var isShowing = false;

        if ($(this).hasClass("show")) {
            isShowing = true
        }

        if ($("div.cards").hasClass("showing")) {
            // a card is already in view
            $("div.card.show")
                .removeClass("show");

            if (isShowing) {
                // this card was showing - reset the grid
                $("div.cards")
                    .removeClass("showing");
            } else {
                // this card isn't showing - get in with it
                $(this)
                    .css({ zIndex: zindex })
                    .addClass("show");

            }

            zindex++;

        } else {
            // no cards in view
            $("div.cards")
                .addClass("showing");
            $(this)
                .css({ zIndex: zindex })
                .addClass("show");

            zindex++;
        }

    });
});


//END OF BUSINESS DIVS  GRIDS




// popup model  validation for next button to login
function myFunction() {
    var checkBox = document.getElementById("myCheck");
    var g = document.getElementById("green");
    var g2 = document.getElementById("green2");
    var text = document.getElementById("text");
    if (checkBox.checked == true) {
        /* if checkbox is checked*/
        text.style.display = "none"
        green.style.color = "green"
        green2.style.color = "green"
        green.style.opacity = "1"
        green2.style.opacity = "1"



    } else {

        /* if checkbox not checked*/

        green.style.color = "black"
        green2.style.color = "blue"
        green.style.opacity = ".8"
        green2.style.opacity = "0.8"

    }

}

function validateForm() {
    var g = document.getElementById("green");
    var g2 = document.getElementById("green2");
    var checkBox = document.getElementById("myCheck");
    var text = document.getElementById("text");
    if (checkBox.checked == false) {
        /* if checkbox not checked*/
        text.style.display = "block"
        green.style.color = "red"
        green2.style.color = "red"
        green.style.opacity = "1"
        green2.style.opacity = "1"

        text.style.webkitAnimationName = "example" /* Safari 4.0 - 8.0 */
        text.style.webkitAnimationDuration = "1s" /* Safari 4.0 - 8.0 */
        text.style.animationName = "example"
        text.style.animationDuration = "1s"

        return false;
    } else if (checkBox.checked == true) {
        /* if checkbox is checked*/

        green.style.color = "green"
        green2.style.color = "green"
        green.style.opacity = "1"
        green2.style.opacity = "1"


        return true;

    }







}





//MOdal terms and conditions modal

// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

//MOdal login/create account 

// Get the modal
var modal2 = document.getElementById('id00');


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal2) {
        modal2.style.display = "none";
    }
}
var modal3 = document.getElementById('id03');


// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal3) {
        modal3.style.display = "none";
    }
}

//MOdal login/create account 

// validate the forms





function validate2() {
    var Forkl = document.getElementById("forGotten");
    var redN = document.getElementById("businessName");
    var redE = document.getElementById("password1");
    var messa = document.getElementById("msg1");



    var x = document.forms["myForm"]["businessName", "password1"].value;

    if (x == "") {
        redN.style.borderColor = "red"
        redE.style.borderColor = "red"

        Forkl.style.display = "block"

        messa.style.display = "block"


        return false;
    } else {

        return true;
    }




}


function validate3() {
    var s = document.getElementById("sent");
    var n = document.getElementById("notSent");

    var r = document.getElementById('ForgotPassword');
    var c = document.forms["myForm3"]["ForgotPassword"].value;
    var atpos = c.indexOf("@");
    var dotpos = c.lastIndexOf(".");
    if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= c.length) {
        n.style.display = "block"

        s.style.display = "none"
        r.style.borderColor = "red";


        return false;
    } else if (c == "") {
        s.style.display = "block"
        r.style.borderColor = "red";
    }
}
/*

function validate3() {
    var s = document.getElementById("sent");
    var n = document.getElementById("notSent");

    var r = document.getElementById('ForgotPassword');

    var e = document.forms["myForm3"]["ForgotPassword"].value;

    if (e == "") {
        n.style.display = "block"

        s.style.display = "none"
        r.style.borderColor = "red";
        return false;
    } else {

        n.style.display = "none"


        return true;
    }
*/






function validate4() {

    var n = document.getElementById("notSento");


    var r = document.getElementById('reccode');

    var e = document.forms["myForm4"]["reccode"].value;

    if (e == "") {
        n.style.display = "block"



        r.style.borderColor = "red";
        return false;
    } else {
        n.style.display = "none"


        return true;
    }



}